@echo off
setlocal
pushd "%~dp0"
if errorlevel 1 goto failed
set "TEAM18_ENV=%LOCALAPPDATA%\MessengerTeam18\venv"
if exist "%TEAM18_ENV%\Scripts\python.exe" goto install
py -3 -m venv "%TEAM18_ENV%"
if errorlevel 1 goto failed
:install
"%TEAM18_ENV%\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto failed
"%TEAM18_ENV%\Scripts\python.exe" run_server.py
if errorlevel 1 goto failed
popd
exit /b 0
:failed
echo Failed. Read the error above and send a screenshot.
pause
popd
exit /b 1
