"""20 parallel HTTP workers; isolated temporary DB, no real data touched."""
import os, sys, tempfile, time, json, logging
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from threading import Thread
from urllib.request import Request, urlopen
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
temp = tempfile.TemporaryDirectory()
os.environ['MESSENGER_DATA_DIR'] = temp.name
from app import create_app
from app.extensions import db
from app.models import User, Channel, Membership, Message
from werkzeug.serving import make_server
app = create_app()
with app.app_context():
    db.create_all()
    user=User(username='load_user'); user.set_password('Load123!'); db.session.add(user); db.session.flush()
    channel=Channel(name='load',creator_id=user.id); db.session.add(channel); db.session.flush()
    db.session.add(Membership(user_id=user.id,channel_id=channel.id))
    db.session.add_all([Message(sender_id=user.id,channel_id=channel.id,text=f'Test message {i}') for i in range(1000)])
    db.session.commit()
client=app.test_client()
response=client.post('/login',data={'username':'load_user','password':'Load123!'})
cookie=response.headers['Set-Cookie'].split(';',1)[0]
logging.getLogger('werkzeug').setLevel(logging.ERROR)
server=make_server('127.0.0.1',0,app,threaded=True)
thread=Thread(target=server.serve_forever,daemon=True); thread.start()
base=f'http://127.0.0.1:{server.server_port}'
paths=['/api/v1/health','/api/v1/channels','/api/v1/chats','/api/v1/channels/1/messages','/api/v1/messages/search?q=message']
def call(i):
    writing=i>=400
    path='/api/v1/messages' if writing else paths[i%len(paths)]
    data=json.dumps({'channel_id':1,'text':f'Concurrent {i}'}).encode() if writing else None
    req=Request(base+path,data=data,headers={'Cookie':cookie,'Content-Type':'application/json'})
    start=time.perf_counter()
    with urlopen(req,timeout=20) as r:
        r.read(); status=r.status
    return time.perf_counter()-start,status
try:
    with ThreadPoolExecutor(max_workers=20) as pool:
        reads=list(pool.map(call,range(400)))
        writes=list(pool.map(call,range(400,440)))
    def stats(rows):
        times=sorted(r[0] for r in rows)
        return {'requests':len(rows),'p95_ms':round(times[int(.95*len(times))-1]*1000,2),'max_ms':round(max(times)*1000,2),'statuses':sorted(set(r[1] for r in rows))}
    result={'workers':20,'seed_messages':1000,'reads':stats(reads),'writes':stats(writes)}
    print(json.dumps(result,indent=2))
    assert result['reads']['statuses']==[200] and result['writes']['statuses']==[201]
    assert result['reads']['p95_ms']<=1000 and result['writes']['p95_ms']<=1000
finally:
    server.shutdown(); thread.join()
    with app.app_context(): db.engine.dispose()
