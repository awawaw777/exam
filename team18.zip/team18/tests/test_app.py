import os
import tempfile
import unittest
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor

_temp = tempfile.TemporaryDirectory()
os.environ['MESSENGER_DATA_DIR'] = _temp.name
from app import create_app
from app.extensions import db
from app.models import User, Message
from app.auth import _attempts

class MessengerTests(unittest.TestCase):
    def setUp(self):
        self.app = create_app()
        self.app.config['TESTING'] = True
        _attempts.clear()
        with self.app.app_context():
            db.drop_all()
            db.create_all()
        self.a, self.b, self.c = [self.app.test_client() for _ in range(3)]
        for client, name in zip((self.a,self.b,self.c),('alice','bob','eve')):
            self.assertEqual(client.post('/register', data={'username':name,'password':'Test123!'}).status_code,302)
            self.assertEqual(client.post('/login', data={'username':name,'password':'Test123!'}).status_code,302)
        self.chat = self.a.post('/api/v1/chats', json={'username':'bob'}).json['id']
        self.channel = self.a.post('/api/v1/channels', json={'name':'general'}).json['id']

    def test_auth_and_health(self):
        c = self.app.test_client()
        self.assertEqual(c.get('/api/v1/health').json['team_id'],'team18')
        for path in ('/channels','/chats',f'/chats/{self.chat}/messages',f'/channels/{self.channel}/messages','/messages/search?q=a',f'/chats/{self.chat}/export'):
            self.assertEqual(c.get('/api/v1'+path).status_code,401,path)
        for path in ('/channels','/chats','/messages','/profile',f'/channels/{self.channel}/join'):
            self.assertEqual(c.post('/api/v1'+path,json={}).status_code,401,path)

    def test_channels_and_chats(self):
        self.assertIsInstance(self.a.get('/api/v1/chats').json,list)
        same = self.b.post('/api/v1/chats',json={'username':'alice'})
        self.assertEqual(same.status_code,200)
        self.assertEqual(same.json['id'],self.chat)
        self.assertEqual(self.c.get('/api/v1/chats').json,[])
        self.assertEqual(self.b.post('/api/v1/messages',json={'channel_id':self.channel,'text':'hi'}).status_code,403)
        for _ in range(2): self.assertEqual(self.b.post(f'/api/v1/channels/{self.channel}/join').status_code,200)
        self.assertEqual(self.b.post('/api/v1/messages',json={'channel_id':self.channel,'text':'hi'}).status_code,201)
        self.assertEqual(len(self.c.get(f'/api/v1/channels/{self.channel}/messages').json),1)

    def test_private_access_and_search(self):
        self.assertEqual(self.a.post('/api/v1/messages',json={'chat_id':self.chat,'text':'secretXYZ'}).status_code,201)
        self.assertEqual(self.b.get(f'/api/v1/chats/{self.chat}/messages').json[0]['text'],'secretXYZ')
        for path in (f'/api/v1/chats/{self.chat}/messages',f'/api/v1/chats/{self.chat}/export',f'/chats/{self.chat}'):
            self.assertEqual(self.c.get(path).status_code,403,path)
        self.assertEqual(self.c.post('/api/v1/messages',json={'chat_id':self.chat,'text':'intruder'}).status_code,403)
        self.assertEqual(self.c.get('/api/v1/messages/search?q=secretXYZ').json,[])
        self.assertEqual(len(self.a.get('/api/v1/messages/search?q=secretXYZ').json),1)

    def test_xss_and_profile(self):
        payload='<script>alert(1)</script>'
        self.a.post('/api/v1/messages',json={'chat_id':self.chat,'text':payload})
        page=self.a.get(f'/chats/{self.chat}').get_data(as_text=True)
        self.assertNotIn(payload,page)
        self.assertIn('&lt;script&gt;',page)
        self.assertEqual(self.a.post('/api/v1/profile',json={'bio':payload}).status_code,200)
        page=self.c.get('/u/alice').get_data(as_text=True)
        self.assertNotIn(payload,page)
        self.assertIn('&lt;script&gt;',page)
        self.assertIn('general',page)

    def test_sql_injection_and_literals(self):
        self.a.post('/api/v1/messages',json={'chat_id':self.chat,'text':'secretXYZ'})
        for payload in ("' OR '1'='1", "1' UNION SELECT 1,username,password_hash,4,5 FROM user--", "'; SELECT sleep(5); --", '%', '_'):
            r=self.c.get('/api/v1/messages/search',query_string={'q':payload})
            self.assertEqual(r.status_code,200)
            self.assertEqual(r.json,[])

    def test_export(self):
        self.a.post('/api/v1/messages',json={'chat_id':self.chat,'text':'Привет'})
        r=self.a.get(f'/api/v1/chats/{self.chat}/export?format=txt')
        self.assertEqual(r.status_code,200)
        self.assertIn('Привет',r.get_data(as_text=True))
        self.assertIn(f'chat_{self.chat}.txt',r.headers['Content-Disposition'])
        for payload in ('../../../../etc/passwd','..\\..\\windows\\win.ini','/etc/hostname','json'):
            self.assertEqual(self.a.get(f'/api/v1/chats/{self.chat}/export',query_string={'format':payload}).status_code,400)

    def test_cookie_and_bruteforce(self):
        r=self.a.post('/login',data={'username':'alice','password':'Test123!'})
        cookie=r.headers['Set-Cookie']
        self.assertIn('HttpOnly',cookie)
        self.assertIn('SameSite=Lax',cookie)
        results=[self.c.post('/login',data={'username':'referee_bf','password':'wrong'}) for _ in range(50)]
        self.assertTrue(any(r.status_code==429 and 'Retry-After' in r.headers for r in results))
        self.assertEqual(self.c.get('/api/v1/health').status_code,200)

    def test_invalid_input(self):
        for value in ([],None,{}, {'text':'ok'}, {'chat_id':True,'text':'ok'}, {'chat_id':self.chat,'channel_id':self.channel,'text':'ok'}, {'chat_id':self.chat,'text':[]}, {'chat_id':self.chat,'text':'x'*10001}):
            self.assertEqual(self.a.post('/api/v1/messages',json=value).status_code,400,str(value)[:100])
        self.assertEqual(self.a.get('/api/v1/chats/9999/messages').status_code,404)
        self.assertEqual(self.a.post('/api/v1/chats',json={'username':'missing'}).status_code,404)
        self.assertEqual(self.a.post('/api/v1/chats',json={'username':'alice'}).status_code,400)
        self.assertEqual(self.a.get('/api/v1/messages/search').status_code,400)

    def test_pagination_and_full_export(self):
        with self.app.app_context():
            db.session.add_all([Message(sender_id=1, chat_id=self.chat, text=f'pageitem{i}') for i in range(125)])
            db.session.commit()
        latest = self.a.get(f'/api/v1/chats/{self.chat}/messages').json
        self.assertEqual(len(latest), 100)
        older = self.a.get(f'/api/v1/chats/{self.chat}/messages?before={latest[0]["id"]}').json
        self.assertEqual(len(older), 25)
        self.assertLess(older[-1]['id'], latest[0]['id'])
        full = self.a.get(f'/api/v1/chats/{self.chat}/export').get_data(as_text=True)
        self.assertEqual(full.count('pageitem'), 125)
        self.assertEqual(self.a.get(f'/api/v1/chats/{self.chat}/messages?limit=0').status_code, 400)

    def test_parallel_chat_creation(self):
        def create(_):
            c=self.app.test_client()
            with c.session_transaction() as session: session['user_id']=1
            return c.post('/api/v1/chats',json={'username':'eve'})
        with ThreadPoolExecutor(max_workers=20) as pool:
            results=list(pool.map(create,range(20)))
        self.assertTrue(all(r.status_code in (200,201) for r in results))
        self.assertEqual(len({r.json['id'] for r in results}),1)

if __name__=='__main__': unittest.main(verbosity=2)
