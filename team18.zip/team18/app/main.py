from flask import Blueprint, render_template, session, g, abort
from .models import User, Channel, Membership
from .extensions import db
from .security import authenticated
from .api import history_page
bp = Blueprint('main', __name__)

@bp.get('/')
def index():
    user = db.session.get(User, session['user_id']) if session.get('user_id') else None
    return render_template('index.html', user=user)

@bp.get('/u/<username>')
def profile(username):
    user = User.query.filter_by(username=username).first()
    if user is None:
        abort(404)
    channels = Channel.query.join(Membership).filter(Membership.user_id == user.id).order_by(Channel.name).all()
    return render_template('profile.html', user=user, channels=channels)

@bp.get('/chats/<int:ident>')
@bp.get('/chat/<int:ident>')
@authenticated
def chat(ident):
    return render_template('room.html', kind='chat', ident=ident, messages=history_page('chat', ident))

@bp.get('/channels/<int:ident>')
@bp.get('/channel/<int:ident>')
@authenticated
def channel(ident):
    return render_template('room.html', kind='channel', ident=ident, messages=history_page('channel', ident))
