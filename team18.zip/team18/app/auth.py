import re
import time
from collections import OrderedDict, deque
from threading import Lock
from flask import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify
from .models import User
from .extensions import db

bp = Blueprint('auth', __name__)
_attempts = OrderedDict()
_lock = Lock()

def throttle(username):
    now = time.monotonic()
    keys = [('account', username.casefold()), ('ip', request.remote_addr)]
    with _lock:
        for key, maximum in zip(keys, (10, 120)):
            entries = _attempts.setdefault(key, deque())
            _attempts.move_to_end(key)
            while entries and entries[0] <= now - 60:
                entries.popleft()
            if len(entries) >= maximum:
                return max(1, int(61 - (now - entries[0])))
        for key in keys:
            _attempts[key].append(now)
        while len(_attempts) > 10000:
            _attempts.popitem(last=False)
    return 0

@bp.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        if not re.fullmatch(r'[\w.-]{1,80}', username) or not 1 <= len(password) <= 256:
            flash('Логин: 1–80 букв, цифр, точек, дефисов или _. Пароль: 1–256 символов.')
            return render_template('auth/register.html'), 400
        if User.query.filter_by(username=username).first():
            flash('Пользователь уже существует')
            return render_template('auth/register.html'), 400
        user = User(username=username)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()
        return redirect(url_for('auth.login'))
    return render_template('auth/register.html')

@bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()[:80]
        delay = throttle(username)
        if delay:
            return jsonify(error='Слишком много попыток. Повторите через минуту.'), 429, {'Retry-After': str(delay)}
        password = request.form.get('password', '')
        user = User.query.filter_by(username=username).first()
        if len(password) <= 256 and user and user.check_password(password):
            session.clear()
            session['user_id'] = user.id
            return redirect(url_for('main.index'))
        flash('Неверные данные')
        return render_template('auth/login.html'), 401
    return render_template('auth/login.html')

@bp.get('/logout')
def logout():
    session.clear()
    return redirect(url_for('main.index'))
