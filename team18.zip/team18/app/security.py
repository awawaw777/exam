from functools import wraps
from flask import session, abort, g, request
from .extensions import db
from .models import User, Chat, Channel, Membership

def authenticated(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        uid = session.get('user_id')
        g.user = db.session.get(User, uid) if isinstance(uid, int) else None
        if g.user is None:
            abort(401, description='Войдите в аккаунт')
        return fn(*args, **kwargs)
    return wrapped

def room(kind, ident, write=False):
    model = Chat if kind == 'chat' else Channel
    item = db.session.get(model, ident)
    if item is None:
        abort(404, description='Чат или канал не найден')
    if kind == 'chat' and g.user.id not in (item.user_a, item.user_b):
        abort(403, description='Нет доступа к приватному чату')
    if kind == 'channel' and write and db.session.get(Membership, (g.user.id, ident)) is None:
        abort(403, description='Сначала вступите в канал')
    return item

def body():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        abort(400, description='Ожидается JSON-объект')
    return data

def text_value(data, key, maximum, empty=False):
    value = data.get(key)
    if not isinstance(value, str) or len(value) > maximum or (not empty and not value.strip()):
        abort(400, description=f'Некорректное поле {key}, максимум {maximum} символов')
    return value
