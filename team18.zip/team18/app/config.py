import os
from pathlib import Path
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / '.env')
DATA = Path(os.environ.get('MESSENGER_DATA_DIR', str(ROOT / 'instance'))).resolve()
DATA.mkdir(parents=True, exist_ok=True)

def database_url():
    if os.environ.get('MESSENGER_DATA_DIR'):
        return 'sqlite:///' + str(DATA / 'team18.db')
    value = os.environ.get('DATABASE_URL', 'sqlite:///team18.db')
    if value.startswith('sqlite:///'):
        path = value[len('sqlite:///'):]
        if not os.path.isabs(path):
            path = str(DATA / path)
        return 'sqlite:///' + path
    return value

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY')
    SQLALCHEMY_DATABASE_URI = database_url()
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {'connect_args': {'timeout': 15, 'check_same_thread': False}, 'pool_size': 20, 'max_overflow': 5}
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'
    SESSION_COOKIE_SECURE = os.environ.get('COOKIE_SECURE', '0') == '1'
    SESSION_COOKIE_NAME = 'team18_session'
    MAX_CONTENT_LENGTH = 65536
    TEAM_ID = os.environ.get('TEAM_ID', 'team18')
    TEAM_NAME = os.environ.get('TEAM_NAME', 'Team Romeo')
    API_KEY = os.environ.get('API_KEY', '')
