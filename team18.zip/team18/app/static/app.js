'use strict';
const notice = document.querySelector('#notice');
function report(e) { if (notice) notice.textContent = e.message || String(e); }
async function api(path, data) {
  const response = await fetch('/api/v1' + path, data === undefined ? {} : {
    method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(data)
  });
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || 'Ошибка запроса');
  return result;
}
function onForm(id, action) {
  const form = document.getElementById(id);
  if (form) form.addEventListener('submit', async e => {
    e.preventDefault();
    const button = form.querySelector('button'); button.disabled = true;
    try { await action(Object.fromEntries(new FormData(form)), form); } catch(e) { report(e); }
    finally { button.disabled = false; }
  });
}
async function refresh() {
  for (const type of ['channels', 'chats']) {
    const list = document.getElementById(type); if (!list) continue;
    const rows = await api('/' + type); list.replaceChildren();
    for (const row of rows) {
      const li = document.createElement('li'); const link = document.createElement('a');
      link.href = '/' + type + '/' + row.id;
      link.textContent = row.name || row.username;
      li.append(link);
      if (type === 'channels') li.append(document.createTextNode(row.joined ? ' · вы участник' : ' · публичный'));
      list.append(li);
    }
  }
}
onForm('channel-form', async data => { await api('/channels', data); await refresh(); });
onForm('chat-form', async data => { const row = await api('/chats', data); location.href = '/chats/' + row.id; });
onForm('profile-form', async data => { await api('/profile', data); notice.textContent = 'Профиль сохранён'; });
onForm('search-form', async data => {
  const rows = await api('/messages/search?q=' + encodeURIComponent(data.q));
  const list = document.querySelector('#results'); list.replaceChildren();
  for (const row of rows) {
    const li = document.createElement('li'); const link = document.createElement('a');
    link.href = row.chat_id ? '/chats/' + row.chat_id : '/channels/' + row.channel_id;
    link.textContent = row.username + ': ' + row.text; li.append(link); list.append(li);
  }
  if (!rows.length) list.textContent = 'Ничего не найдено';
});
onForm('message-form', async (data, form) => {
  data[form.dataset.kind + '_id'] = Number(form.dataset.id);
  await api('/messages', data); location.reload();
});
const join = document.querySelector('#join');
if (join) join.addEventListener('click', async () => {
  try { await api('/channels/' + join.dataset.id + '/join', {}); notice.textContent = 'Вы вступили в канал'; }
  catch(e) { report(e); }
});
refresh().catch(report);
