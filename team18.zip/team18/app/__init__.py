import secrets
import sqlite3
from flask import Flask, jsonify, request
from sqlalchemy import event
from sqlalchemy.engine import Engine
from sqlalchemy.exc import IntegrityError, OperationalError
from werkzeug.exceptions import HTTPException
from .extensions import db
from .config import Config, DATA

@event.listens_for(Engine, 'connect')
def sqlite_settings(connection, record):
    if isinstance(connection, sqlite3.Connection):
        cursor = connection.cursor()
        cursor.execute('PRAGMA foreign_keys=ON')
        cursor.execute('PRAGMA busy_timeout=15000')
        # DELETE journal works on SMB too; launcher keeps the working DB local.
        cursor.execute('PRAGMA synchronous=FULL')
        cursor.close()

def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)
    if not app.config.get('SECRET_KEY') or app.config['SECRET_KEY'] in ('dev-secret-key', 'team18-secret-key'):
        keyfile = DATA / '.session-key'
        try:
            with keyfile.open('x') as f:
                f.write(secrets.token_hex(32))
        except FileExistsError:
            pass
        app.config['SECRET_KEY'] = keyfile.read_text().strip()
    db.init_app(app)
    from .auth import bp as auth_bp
    from .api import bp as api_bp
    from .main import bp as main_bp
    app.register_blueprint(auth_bp)
    app.register_blueprint(api_bp, url_prefix='/api/v1')
    app.register_blueprint(main_bp)

    @app.cli.command('init-db')
    def init_db():
        db.create_all()
        print('Database ready:', app.config['TEAM_ID'])

    @app.errorhandler(HTTPException)
    def http_error(error):
        return jsonify(error=error.description), error.code

    @app.errorhandler(IntegrityError)
    def conflict(error):
        db.session.rollback()
        return jsonify(error='Объект уже существует или данные некорректны'), 400

    @app.errorhandler(OperationalError)
    def unavailable(error):
        db.session.rollback()
        app.logger.exception('Database operation failed')
        return jsonify(error='База временно занята; повторите запрос'), 503

    @app.after_request
    def headers(response):
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'DENY'
        response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self'; style-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'"
        response.headers['Cache-Control'] = 'no-store'
        return response
    with app.app_context():
        db.create_all()
    return app
