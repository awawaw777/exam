from io import BytesIO
from flask import Blueprint, jsonify, current_app, request, g, abort, send_file
from sqlalchemy import or_, select
from sqlalchemy.exc import IntegrityError
from .extensions import db
from .models import User, Channel, Membership, Chat, Message
from .security import authenticated, room, body, text_value

bp = Blueprint('api', __name__)

def message_json(m):
    return dict(id=m.id, sender_id=m.sender_id, username=m.sender.username, text=m.text,
                chat_id=m.chat_id, channel_id=m.channel_id, created_at=m.created_at.isoformat() + 'Z')

def chat_json(c):
    other = db.session.get(User, c.user_b if c.user_a == g.user.id else c.user_a)
    return dict(id=c.id, username=other.username, participants=[c.user_a, c.user_b])

def history(kind, ident):
    room(kind, ident)
    return Message.query.filter_by(**{kind + '_id': ident}).join(User, User.id == Message.sender_id).order_by(Message.id)

def query_json(query):
    rows = query.with_entities(Message.id, Message.sender_id, User.username, Message.text,
                               Message.chat_id, Message.channel_id, Message.created_at).all()
    return [dict(id=r.id, sender_id=r.sender_id, username=r.username, text=r.text,
                 chat_id=r.chat_id, channel_id=r.channel_id, created_at=r.created_at.isoformat() + 'Z') for r in rows]

def history_page(kind, ident, as_json=False):
    query = history(kind, ident)
    try:
        limit = int(request.args.get('limit', '100'))
        before = int(request.args.get('before', '0'))
        if not 1 <= limit <= 200 or before < 0:
            raise ValueError
    except ValueError:
        abort(400, description='limit: 1–200, before: неотрицательный ID')
    if before:
        query = query.filter(Message.id < before)
    query = query.order_by(None).order_by(Message.id.desc()).limit(limit)
    return list(reversed(query_json(query) if as_json else query.all()))

@bp.get('/health')
def health():
    return jsonify(status='ok', team_id=current_app.config['TEAM_ID'], team_name=current_app.config['TEAM_NAME'])

@bp.route('/channels', methods=['GET', 'POST'])
@authenticated
def channels():
    if request.method == 'POST':
        name = text_value(body(), 'name', 80).strip()
        if Channel.query.filter_by(name=name).first():
            abort(400, description='Канал с таким именем уже существует')
        channel = Channel(name=name, creator_id=g.user.id)
        db.session.add(channel)
        db.session.flush()
        db.session.add(Membership(user_id=g.user.id, channel_id=channel.id))
        db.session.commit()
        return jsonify(id=channel.id, name=channel.name, joined=True), 201
    joined = set(db.session.scalars(select(Membership.channel_id).where(Membership.user_id == g.user.id)))
    return jsonify([dict(id=c.id, name=c.name, joined=c.id in joined) for c in Channel.query.order_by(Channel.id)])

@bp.post('/channels/<int:ident>/join')
@authenticated
def join(ident):
    room('channel', ident)
    if db.session.get(Membership, (g.user.id, ident)) is None:
        db.session.add(Membership(user_id=g.user.id, channel_id=ident))
        try:
            db.session.commit()
        except IntegrityError:
            db.session.rollback()
    return jsonify(status='ok', channel_id=ident)

@bp.route('/chats', methods=['GET', 'POST'])
@authenticated
def chats():
    if request.method == 'GET':
        rows = Chat.query.filter(or_(Chat.user_a == g.user.id, Chat.user_b == g.user.id)).order_by(Chat.id)
        return jsonify([chat_json(c) for c in rows])
    username = text_value(body(), 'username', 80).strip()
    other = User.query.filter_by(username=username).first()
    if other is None:
        abort(404, description='Пользователь не найден')
    if other.id == g.user.id:
        abort(400, description='Выберите другого пользователя')
    a, b = sorted((g.user.id, other.id))
    chat = Chat.query.filter_by(user_a=a, user_b=b).first()
    status = 200
    if chat is None:
        chat = Chat(user_a=a, user_b=b)
        db.session.add(chat)
        try:
            db.session.commit()
            status = 201
        except IntegrityError:
            db.session.rollback()
            chat = Chat.query.filter_by(user_a=a, user_b=b).one()
    return jsonify(chat_json(chat)), status

@bp.post('/messages')
@authenticated
def messages():
    data = body()
    content = text_value(data, 'text', 10000)
    targets = [k for k in ('chat_id', 'channel_id') if k in data]
    if len(targets) != 1:
        abort(400, description='Нужен ровно один chat_id или channel_id')
    key = targets[0]
    ident = data[key]
    if type(ident) is not int or ident <= 0:
        abort(400, description='ID должен быть положительным целым числом')
    room(key[:-3], ident, write=True)
    m = Message(sender_id=g.user.id, text=content, **{key: ident})
    db.session.add(m)
    db.session.commit()
    return jsonify(message_json(m)), 201

@bp.get('/chats/<int:ident>/messages')
@authenticated
def chat_messages(ident):
    return jsonify(history_page('chat', ident, as_json=True))

@bp.get('/channels/<int:ident>/messages')
@authenticated
def channel_messages(ident):
    return jsonify(history_page('channel', ident, as_json=True))

@bp.get('/messages/search')
@authenticated
def search():
    q = request.args.get('q', '')
    if not q.strip() or len(q) > 200:
        abort(400, description='Поисковая строка: от 1 до 200 символов')
    own = select(Chat.id).where(or_(Chat.user_a == g.user.id, Chat.user_b == g.user.id))
    rows = Message.query.join(User, User.id == Message.sender_id).filter(or_(Message.channel_id.isnot(None), Message.chat_id.in_(own)),
                                Message.text.contains(q, autoescape=True)).order_by(Message.id.desc()).limit(200)
    return jsonify(query_json(rows))

@bp.post('/profile')
@authenticated
def profile():
    g.user.bio = text_value(body(), 'bio', 2000, empty=True)
    db.session.commit()
    return jsonify(username=g.user.username, bio=g.user.bio)

def export(kind, ident):
    rows = history(kind, ident)
    if request.args.get('format', 'txt') != 'txt':
        abort(400, description='Поддерживается только format=txt')
    content = '\n'.join(f'{m.created_at.isoformat()} {m.sender.username}: {m.text}' for m in rows)
    return send_file(BytesIO(content.encode('utf-8')), mimetype='text/plain; charset=utf-8',
                     as_attachment=True, download_name=f'{kind}_{ident}.txt')

@bp.get('/chats/<int:ident>/export')
@authenticated
def chat_export(ident):
    return export('chat', ident)

@bp.get('/channels/<int:ident>/export')
@authenticated
def channel_export(ident):
    return export('channel', ident)
