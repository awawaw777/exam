"""Local runtime for code stored on a Windows network share."""
import os
import sqlite3
from pathlib import Path
from dotenv import load_dotenv
ROOT = Path(__file__).resolve().parent
load_dotenv(ROOT / '.env')
if os.name == 'nt':
    data = Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'MessengerTeam18' / 'data'
    data.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault('MESSENGER_DATA_DIR', str(data))
    data = Path(os.environ['MESSENGER_DATA_DIR'])
    data.mkdir(parents=True, exist_ok=True)
    target = data / 'team18.db'
    source = ROOT / 'instance' / 'team18.db'
    if not target.exists() and source.exists():
        with sqlite3.connect(str(source)) as src, sqlite3.connect(str(target)) as dst:
            src.backup(dst)
from app import create_app
from app.extensions import db
app = create_app()
if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    port = int(os.environ.get('PORT', '5018'))
    print('Team:', app.config['TEAM_ID'], flush=True)
    print('Database:', app.config['SQLALCHEMY_DATABASE_URI'], flush=True)
    print(f'Open http://127.0.0.1:{port}', flush=True)
    app.run(host=os.environ.get('HOST', '0.0.0.0'), port=port, debug=False, threaded=True, use_reloader=False)
