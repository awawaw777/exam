import csv
import io
import re
import sqlite3
import tempfile
import threading
import unittest
import urllib.request
import urllib.error
import urllib.parse
from pathlib import Path
from http.server import HTTPServer
from core import Inventory
from init_db import initialize
from backup import create_backup,restore
from maintenance import maintain
from app import Handler

class SystemTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        self.path=self.root/'test.db';initialize(self.path);self.db=Inventory(self.path)
    def tearDown(self):
        self.db.close();self.tmp.cleanup()
    def add(self,inv='NEW-001',serial='SN-NEW',cost='12.34'):
        return self.db.add_equipment(inv,serial,'Тестовый прибор',1,1,1,'2025-09-01',cost)
    def test_01_seed(self):
        self.assertEqual(len(self.db.list_equipment()),12)
        self.assertEqual(sum(r['cost_kopecks'] for r in self.db.list_equipment()),45800000)
    def test_02_register_and_unique(self):
        key=self.add();self.assertEqual(self.db.get(key)['cost_kopecks'],1234)
        for inv,serial in [('NEW-001','OTHER'),('OTHER','SN-NEW')]:
            with self.assertRaises(sqlite3.IntegrityError):self.add(inv,serial)
        self.assertEqual(len(self.db.list_equipment()),13)
    def test_03_validation(self):
        for cost in ('-1','NaN','1.001','abc'):
            with self.assertRaises(ValueError):self.add(cost=cost)
        with self.assertRaises(ValueError):self.add(inv=' ')
    def test_04_search_and_filter(self):
        self.assertEqual(len(self.db.list_equipment('мфу')),2)
        self.assertEqual(len(self.db.list_equipment(status='В ремонте')),1)
    def test_05_movement_and_rollback(self):
        self.db.move(1,2,2,'П-02');self.assertEqual(self.db.get(1)['room_id'],2)
        count=len(self.db.movements())
        with self.assertRaises(sqlite3.IntegrityError):self.db.move(1,999,2,'Ошибка')
        self.assertEqual(len(self.db.movements()),count);self.assertEqual(self.db.get(1)['room_id'],2)
    def test_06_ticket_lifecycle(self):
        ticket=self.db.open_ticket(1,'Не включается','Инженер')
        self.assertEqual(self.db.get(1)['status'],'В ремонте')
        with self.assertRaises(ValueError):self.db.open_ticket(1,'Повтор','Инженер')
        self.db.close_ticket(ticket,'Заменён блок питания')
        self.assertEqual(self.db.get(1)['status'],'В эксплуатации')
        with self.assertRaises(ValueError):self.db.close_ticket(ticket,'Повтор')
    def test_07_retirement(self):
        self.db.retire(1,'Акт С-01')
        with self.assertRaises(ValueError):self.db.move(1,2,2,'П-03')
        with self.assertRaises(ValueError):self.db.open_ticket(1,'Ремонт','Инженер')
        with self.assertRaises(ValueError):self.db.retire(9,'Акт')
    def test_08_export(self):
        self.add(inv='=1+1')
        content=self.db.csv().decode('utf-8-sig');rows=list(csv.reader(io.StringIO(content),delimiter=';'))
        self.assertEqual(len(rows),14);self.assertIn("'=1+1",content)
        self.assertEqual(len(list(csv.reader(io.StringIO(self.db.csv('мфу').decode('utf-8-sig')),delimiter=';'))),3)
    def test_09_backup_restore(self):
        record=create_backup(self.path,self.root/'backups')
        result=restore(self.root/'backups'/record['archive'],self.root/'restored')
        self.assertEqual(result['counts']['equipment'],12)
        restored=Inventory(self.root/'restored'/'labtech.db')
        try:
            for t in ('categories','rooms','employees','equipment','movements','tickets','audit'):
                self.assertEqual(self.db.rows(f'SELECT * FROM {t} ORDER BY id'),restored.rows(f'SELECT * FROM {t} ORDER BY id'))
        finally:restored.close()
        with self.assertRaises(ValueError):restore(self.root/'backups'/record['archive'],self.root/'restored')
    def test_10_corrupt_backup_rejected(self):
        record=create_backup(self.path,self.root/'backups');archive=self.root/'backups'/record['archive']
        with archive.open('ab') as f:f.write(b'changed')
        with self.assertRaises(ValueError):restore(archive,self.root/'bad')
        self.assertFalse((self.root/'bad').exists())
    def test_11_maintenance(self):
        result=maintain(self.path,self.root/'reports'/'maintenance.json',self.root/'backups')
        self.assertEqual(result['result'],'PASS');self.assertEqual(result['foreign_key_errors'],0)
        self.assertEqual(result['status_errors'],0);self.assertEqual(result['open_tickets'],1)
    def test_12_missing_db(self):
        with self.assertRaises(ValueError):Inventory(self.root/'missing.db')
        self.assertFalse((self.root/'missing.db').exists())
    def test_13_http(self):
        class TestHandler(Handler):
            db_path=self.path
            def log_message(self,*args):pass
        server=HTTPServer(('127.0.0.1',0),TestHandler)
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        base=f'http://127.0.0.1:{server.server_port}'
        try:
            with urllib.request.urlopen(base) as r:page=r.read().decode()
            token=re.search('name="token" value="([^"]+)"',page).group(1)
            self.assertIn('ЛТ-001',page)
            for tab in ('move','tickets','refs','audit','service'):
                with urllib.request.urlopen(base+'/?tab='+tab) as r:self.assertEqual(r.status,200)
            with urllib.request.urlopen(base+'/export') as r:self.assertIn('text/csv',r.headers['Content-Type'])
            data=urllib.parse.urlencode({'token':token,'table':'rooms','name':'Тестовый кабинет'}).encode()
            with urllib.request.urlopen(base+'/reference',data=data) as r:self.assertEqual(r.status,200)
            self.assertEqual(len(self.db.reference('rooms')),5)
            with self.assertRaises(urllib.error.HTTPError) as ctx:
                urllib.request.urlopen(base+'/reference',data=b'token=wrong&table=rooms&name=Bad')
            self.assertEqual(ctx.exception.code,403)
            self.assertEqual(len(self.db.reference('rooms')),5)
        finally:
            server.shutdown();server.server_close();thread.join()

if __name__=='__main__':unittest.main(verbosity=2)
