"""Локальный веб-интерфейс ИС ЛабТехника. Запуск: python app.py."""
import argparse
import html
import secrets
import sqlite3
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs, urlencode, urlsplit
from core import Inventory, DEFAULT_DB, STATUSES

TOKEN = secrets.token_urlsafe(32)
def esc(value):
    return html.escape(str(value),quote=True)

def inp(name,label,kind='text',value='',optional=False):
    return f'<label>{esc(label)}<input name="{esc(name)}" type="{kind}" value="{esc(value)}" {"" if optional else "required"}></label>'

def select(name,label,items):
    options=''.join(f'<option value="{esc(k)}">{esc(v)}</option>' for k,v in items)
    return f'<label>{esc(label)}<select name="{name}">{options}</select></label>'

def form(action,body,button):
    return f'<form method="post" action="/{action}"><input type="hidden" name="token" value="{TOKEN}">{body}<button>{button}</button></form>'

def table(headers,rows):
    return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+esc(h)+'</th>' for h in headers)+'</tr></thead><tbody>'+(''.join('<tr>'+''.join('<td>'+esc(v if v is not None else '—')+'</td>' for v in row)+'</tr>' for row in rows) or f'<tr><td colspan="{len(headers)}">Записей пока нет</td></tr>')+'</tbody></table></div>'

CSS='''*{box-sizing:border-box}body{margin:0;background:#f5f7fa;color:#202d40;font:15px system-ui,sans-serif}header{background:#18334e;color:white;padding:24px 5%}h1{margin:0 0 6px;font-size:30px}header p{margin:0;color:#ccdbea}main{max-width:1450px;margin:auto;padding:24px 4%}nav{display:flex;gap:8px;flex-wrap:wrap;margin:0 0 22px}nav a{padding:10px 15px;background:white;border:1px solid #d5dde5;border-radius:7px;color:#18334e;text-decoration:none}nav a.active{background:#18334e;color:white}.stats{display:flex;gap:16px;flex-wrap:wrap;margin-bottom:24px}.stat{flex:1;min-width:150px;background:white;padding:18px;border:1px solid #dde3e9;border-radius:9px}.stat strong{display:block;font-size:29px}.stat span{color:#5a6d80}h2{margin:24px 0 14px;font-size:23px}h3{font-size:18px}.scroll{overflow:auto}table{width:100%;border-collapse:collapse;background:white;font-size:14px}th,td{padding:12px;text-align:left;border-bottom:1px solid #d9e1e9}th{background:#e9eff5;white-space:nowrap}tbody tr:hover{background:#f3f7fa}form{display:flex;gap:14px;flex-wrap:wrap;align-items:end;background:white;padding:18px;border:1px solid #d9e1e9;border-radius:8px;margin:12px 0 24px}label{display:flex;flex-direction:column;gap:6px;min-width:170px;flex:1}input,select{padding:10px;border:1px solid #b8c5d1;border-radius:5px;font:inherit;width:100%}button,.button{padding:11px 18px;border:0;border-radius:5px;background:#17675c;color:white;font:inherit;cursor:pointer;text-decoration:none}details{margin-top:20px}summary{cursor:pointer;font-weight:600;font-size:18px}.notice{background:#e1eee8;padding:16px;border-radius:7px;margin-bottom:20px}.error{background:#f9e1df}footer{margin:32px 0;color:#69798b;font-size:13px}code{background:#e9eef3;padding:2px 5px}'''

def page(db,tab='inventory',query='',status='',message='',error=False):
    all_rows=db.list_equipment()
    tabs=[('inventory','Реестр'),('move','Перемещения'),('tickets','Ремонт и ТО'),('refs','Справочники'),('audit','Журнал'),('service','Обслуживание')]
    nav='<nav>'+''.join(f'<a class="{"active" if key==tab else ""}" href="/?tab={key}">{title}</a>' for key,title in tabs)+'</nav>'
    stats='<div class="stats">'+''.join(f'<div class="stat"><strong>{value}</strong><span>{label}</span></div>' for label,value in [('Всего единиц',len(all_rows)),('В эксплуатации',sum(r['status']=='В эксплуатации' for r in all_rows)),('В ремонте',sum(r['status']=='В ремонте' for r in all_rows)),('На складе',sum(r['status']=='На складе' for r in all_rows))])+'</div>'
    equipment=[(r['id'],f"{r['inventory']} · {r['title']}") for r in all_rows]
    rooms=[(r['id'],r['name']) for r in db.reference('rooms')]
    employees=[(r['id'],r['name']) for r in db.reference('employees')]
    categories=[(r['id'],r['name']) for r in db.reference('categories')]
    body=''
    if tab=='inventory':
        filtered=db.list_equipment(query,status)
        body='<h2>Реестр оборудования</h2><form method="get"><input type="hidden" name="tab" value="inventory">'+inp('q','Поиск',value=query,optional=True)+'<label>Статус<select name="status">'+''.join(f'<option {"selected" if s==status else ""} value="{esc(s)}">{esc(s or "Все")}</option>' for s in ('',)+STATUSES)+'</select></label><button>Найти</button><a class="button" href="/export?'+urlencode({'q':query,'status':status})+'">Скачать CSV</a></form>'
        body+=table(['Инв. номер','Наименование','Категория','Кабинет','Ответственный','Стоимость, ₽','Статус'],[[r['inventory'],r['title'],r['category'],r['room'],r['employee'],f"{r['cost_kopecks']/100:,.2f}".replace(',',' '),r['status']] for r in filtered])
        body+='<details><summary>Добавить оборудование</summary>'+form('add',inp('inventory','Инвентарный номер')+inp('serial','Серийный номер')+inp('title','Наименование')+select('category_id','Категория',categories)+select('room_id','Кабинет',rooms)+select('employee_id','Ответственный',employees)+inp('purchase_date','Дата приобретения','date')+inp('cost','Стоимость в рублях',value='0.00')+select('status','Начальный статус',[(s,s) for s in ('В эксплуатации','На складе')])+inp('notes','Характеристики',optional=True),'Сохранить')+'</details>'
        body+='<details><summary>Карточки и серийные номера</summary>'+table(['Инв. номер','Серийный номер','Дата приобретения','Характеристики'],[[r['inventory'],r['serial'],r['purchase_date'],r['notes']] for r in filtered])+'</details>'
        body+='<details><summary>Списание по акту</summary>'+form('retire',select('equipment_id','Оборудование',[(r['id'],r['inventory']) for r in all_rows if r['status'] not in ('В ремонте','Списано')])+inp('reason','Номер и дата акта'),'Списать')+'</details>'
    elif tab=='move':
        body='<h2>Внутренние перемещения</h2>'+form('move',select('equipment_id','Оборудование',equipment)+select('room_id','Новый кабинет',rooms)+select('employee_id','Новый ответственный',employees)+inp('reason','Основание перемещения'),'Оформить перемещение')
        body+=table(['Дата','Инв. номер','Откуда','Куда','Прежний ответственный','Новый ответственный','Основание'],[[r[k] for k in ('created_at','inventory','old_room_name','new_room_name','old_employee_name','new_employee_name','reason')] for r in db.movements()])
    elif tab=='tickets':
        tickets=db.tickets()
        body='<h2>Заявки на ремонт и обслуживание</h2>'+form('open',select('equipment_id','Оборудование',equipment)+inp('description','Неисправность или вид ТО')+inp('engineer','Исполнитель'),'Создать заявку')
        body+=table(['№','Инв. номер','Описание','Исполнитель','Статус','Результат','Открыта','Завершена'],[[r[k] for k in ('id','inventory','description','engineer','status','resolution','created_at','closed_at')] for r in tickets])
        active=[(r['id'],f"№ {r['id']} · {r['inventory']}") for r in tickets if r['status']=='Открыта']
        if active:
            body+='<h3>Завершение ремонта</h3>'+form('close',select('ticket_id','Открытая заявка',active)+inp('resolution','Выполненные работы')+select('status','Состояние после ремонта',[(s,s) for s in ('В эксплуатации','На складе')]),'Завершить ремонт')
    elif tab=='refs':
        body='<h2>Справочники</h2>'+form('reference',select('table','Справочник',[('categories','Категории'),('rooms','Кабинеты'),('employees','Ответственные лица')])+inp('name','Новое значение'),'Добавить')
        for key,label in [('categories','Категории'),('rooms','Кабинеты'),('employees','Ответственные лица')]:
            body+='<h3>'+label+'</h3>'+table(['Код','Название'],[[r['id'],r['name']] for r in db.reference(key)])
    elif tab=='audit':
        body='<h2>Журнал операций</h2>'+table(['№','Дата','Операция','Содержание'],[[r[k] for k in ('id','created_at','action','details')] for r in db.rows('SELECT * FROM audit ORDER BY id DESC LIMIT 500')])
    else:
        body='''<h2>Резервное копирование и обслуживание</h2><p>Команды выполняются в терминале из каталога программы. Перед обслуживанием остановите приложение: Ctrl+C.</p><ol><li>Создать копию: <code>python backup.py</code>.</li><li>Проверить и обслужить базу: <code>python maintenance.py</code>.</li><li>Проверить восстановление в отдельный каталог: <code>python backup.py --restore backups/ИМЯ.zip --target restored</code>.</li><li>Проверить восстановленную БД: <code>python app.py --db restored/labtech.db --port 8001</code>.</li></ol><p>Результаты сохраняются в каталогах backups и reports. Подробный порядок восстановления приведён в README.md.</p>'''
    notice=f'<div class="notice {"error" if error else ""}">{esc(message)}</div>' if message else ''
    return '<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ЛабТехника — учёт оборудования</title><style>'+CSS+'</style><header><h1>ЛабТехника</h1><p>Учёт и обслуживание оборудования учебных лабораторий</p></header><main>'+stats+nav+notice+body+'<footer>Рахимов Никита Алексеевич · ИСП44-9 · Учебная база · Локальное рабочее место</footer></main></html>'

class Handler(BaseHTTPRequestHandler):
    db_path=DEFAULT_DB
    def send(self,data,status=200,kind='text/html; charset=utf-8',filename=None):
        payload=data.encode('utf-8') if isinstance(data,str) else data
        self.send_response(status)
        self.send_header('Content-Type',kind)
        self.send_header('Content-Length',str(len(payload)))
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('X-Frame-Options','DENY')
        if filename:
            self.send_header('Content-Disposition',f'attachment; filename="{filename}"')
        self.end_headers()
        self.wfile.write(payload)

    def allowed_host(self):
        return self.headers.get('Host') in (f'127.0.0.1:{self.server.server_port}',f'localhost:{self.server.server_port}')

    def do_GET(self):
        if not self.allowed_host():
            return self.send('Недопустимый адрес',403)
        parsed=urlsplit(self.path)
        q={k:v[0] for k,v in parse_qs(parsed.query).items()}
        if parsed.path not in ('/','/export'):
            return self.send('Страница не найдена',404)
        db=Inventory(self.db_path)
        try:
            if parsed.path=='/export':
                return self.send(db.csv(q.get('q',''),q.get('status','')),kind='text/csv; charset=utf-8',filename='inventory.csv')
            self.send(page(db,q.get('tab','inventory'),q.get('q',''),q.get('status',''),q.get('message','')))
        finally:
            db.close()

    def do_POST(self):
        if not self.allowed_host():
            return self.send('Недопустимый адрес',403)
        origin=self.headers.get('Origin')
        if origin and origin not in (f'http://127.0.0.1:{self.server.server_port}',f'http://localhost:{self.server.server_port}'):
            return self.send('Недопустимый источник запроса',403)
        try:
            length=int(self.headers.get('Content-Length','0'))
            if not 0<length<=16384:
                return self.send('Неверный размер запроса',400)
            values={k:v[0] for k,v in parse_qs(self.rfile.read(length).decode('utf-8'),keep_blank_values=True).items()}
        except (ValueError,UnicodeError):
            return self.send('Неверный запрос',400)
        if not secrets.compare_digest(values.pop('token',''),TOKEN):
            return self.send('Обновите страницу и повторите действие',403)
        db=Inventory(self.db_path)
        tab='inventory'
        try:
            action=urlsplit(self.path).path
            if action=='/add':
                db.add_equipment(**{k:values[k] for k in ('inventory','serial','title','category_id','room_id','employee_id','purchase_date','cost','notes','status')})
            elif action=='/move':
                tab='move'; db.move(values['equipment_id'],values['room_id'],values['employee_id'],values['reason'])
            elif action=='/open':
                tab='tickets'; db.open_ticket(values['equipment_id'],values['description'],values['engineer'])
            elif action=='/close':
                tab='tickets'; db.close_ticket(values['ticket_id'],values['resolution'],values['status'])
            elif action=='/retire':
                db.retire(values['equipment_id'],values['reason'])
            elif action=='/reference':
                tab='refs'; db.add_reference(values['table'],values['name'])
            else:
                return self.send('Операция не найдена',404)
            self.send_response(303)
            self.send_header('Location','/?'+urlencode({'tab':tab,'message':'Операция выполнена'}))
            self.send_header('Content-Length','0')
            self.end_headers()
        except (ValueError,KeyError,sqlite3.IntegrityError) as exc:
            message=str(exc)
            if isinstance(exc,sqlite3.IntegrityError):
                message='Запись уже существует или выбрано отсутствующее значение справочника. Проверьте номера и справочники.'
            self.send(page(db,tab,message=message,error=True),400)
        except sqlite3.OperationalError:
            self.send(page(db,tab,message='База недоступна или занята. Повторите операцию после завершения обслуживания.',error=True),503)
        finally:
            db.close()

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--db',default=str(DEFAULT_DB))
    parser.add_argument('--port',type=int,default=8000)
    args=parser.parse_args()
    try:
        db=Inventory(args.db); db.list_equipment(); db.close()
        Handler.db_path=args.db
        server=HTTPServer(('127.0.0.1',args.port),Handler)
    except (ValueError,OSError,sqlite3.Error) as exc:
        parser.exit(1,f'Ошибка запуска: {exc}\n')
    print(f'ЛабТехника: http://127.0.0.1:{args.port} · Остановка: Ctrl+C',flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
