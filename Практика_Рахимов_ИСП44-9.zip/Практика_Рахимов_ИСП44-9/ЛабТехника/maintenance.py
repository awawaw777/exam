"""Обслуживание остановленной ИС с предварительным резервным копированием."""
import argparse
import json
from pathlib import Path
from core import Inventory, DEFAULT_DB, ROOT, now
from backup import create_backup

def maintain(path=DEFAULT_DB,report=None,backup_dir=None):
    record=create_backup(path,backup_dir)
    db=Inventory(path)
    try:
        integrity=[r[0] for r in db.conn.execute('PRAGMA integrity_check')]
        foreign=[tuple(r) for r in db.conn.execute('PRAGMA foreign_key_check')]
        inconsistencies=db.rows("""SELECT e.id FROM equipment e WHERE
            (e.status='В ремонте') != EXISTS(SELECT 1 FROM tickets t WHERE t.equipment_id=e.id AND t.status='Открыта')""")
        if integrity!=['ok'] or foreign or inconsistencies:
            raise ValueError('Проверка выявила ошибки; оптимизация отменена, используйте резервную копию')
        before=Path(path).stat().st_size
        db.conn.execute('REINDEX'); db.conn.commit()
        db.conn.execute('VACUUM')
        db.conn.execute('ANALYZE'); db.conn.commit()
        with db.conn:
            db.audit('Обслуживание','integrity_check=ok; foreign_key_check=0; REINDEX, VACUUM, ANALYZE')
        result={'time':now(),'backup':record['archive'],'integrity':integrity[0],
                'foreign_key_errors':len(foreign),'status_errors':len(inconsistencies),
                'equipment_count':db.conn.execute('SELECT count(*) FROM equipment').fetchone()[0],
                'open_tickets':db.conn.execute("SELECT count(*) FROM tickets WHERE status='Открыта'").fetchone()[0],
                'completed_tickets':db.conn.execute("SELECT count(*) FROM tickets WHERE status='Выполнена'").fetchone()[0],
                'bytes_before':before,'bytes_after':Path(path).stat().st_size,
                'operations':['REINDEX','VACUUM','ANALYZE'],'result':'PASS'}
        report=Path(report or ROOT/'reports'/'maintenance.json')
        report.parent.mkdir(parents=True,exist_ok=True)
        report.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
        (report.parent/'inventory.csv').write_bytes(db.csv())
        return result
    finally:
        db.close()

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--db',default=str(DEFAULT_DB));a=p.parse_args()
    try:
        print(json.dumps(maintain(a.db),ensure_ascii=False,indent=2))
    except Exception as exc:
        p.exit(1,f'Обслуживание прервано: {exc}\n')
