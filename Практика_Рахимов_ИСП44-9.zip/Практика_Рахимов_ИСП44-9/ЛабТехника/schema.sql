PRAGMA foreign_keys=ON;
CREATE TABLE categories(id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE);
CREATE TABLE rooms(id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE);
CREATE TABLE employees(id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE);
CREATE TABLE equipment(
 id INTEGER PRIMARY KEY, inventory TEXT NOT NULL UNIQUE, serial TEXT NOT NULL UNIQUE,
 title TEXT NOT NULL, category_id INTEGER NOT NULL REFERENCES categories(id),
 room_id INTEGER NOT NULL REFERENCES rooms(id), employee_id INTEGER NOT NULL REFERENCES employees(id),
 purchase_date TEXT NOT NULL, cost_kopecks INTEGER NOT NULL CHECK(cost_kopecks>=0),
 status TEXT NOT NULL CHECK(status IN ('В эксплуатации','На складе','В ремонте','Списано')),
 notes TEXT NOT NULL DEFAULT '');
CREATE TABLE movements(
 id INTEGER PRIMARY KEY, equipment_id INTEGER NOT NULL REFERENCES equipment(id),
 old_room INTEGER NOT NULL REFERENCES rooms(id), new_room INTEGER NOT NULL REFERENCES rooms(id),
 old_employee INTEGER NOT NULL REFERENCES employees(id), new_employee INTEGER NOT NULL REFERENCES employees(id),
 created_at TEXT NOT NULL, reason TEXT NOT NULL);
CREATE TABLE tickets(
 id INTEGER PRIMARY KEY, equipment_id INTEGER NOT NULL REFERENCES equipment(id),
 description TEXT NOT NULL, engineer TEXT NOT NULL, created_at TEXT NOT NULL,
 closed_at TEXT, resolution TEXT, status TEXT NOT NULL CHECK(status IN ('Открыта','Выполнена')));
CREATE UNIQUE INDEX one_active_ticket ON tickets(equipment_id) WHERE status='Открыта';
CREATE TABLE audit(id INTEGER PRIMARY KEY, created_at TEXT NOT NULL, action TEXT NOT NULL, details TEXT NOT NULL);
CREATE INDEX equipment_room ON equipment(room_id);
CREATE INDEX equipment_status ON equipment(status);
